import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { styled } from "styled-components";

import { ChatMakeRequest, ChatMakeRoom } from "@/api/types/chat-type";
import { ApplicantItemList } from "@/components/apply/applicant-item-list";
import { ApplicantModifyModal } from "@/components/apply/applicant-modify-modal";
import { ApplicantOnlyDelete } from "@/components/apply/applicant-only-delete";
import {
  ApplicantListBottomSheetPostProps,
  ApplyListType,
} from "@/components/apply/type";
import { Modal } from "@/components/common/modal";
import { useCheckChatMake } from "@/hooks/chat/useCheckChatMake";
import { useGetApplyList } from "@/hooks/queries/useGetApplyList";
import { useGetPostDetail } from "@/hooks/queries/useGetPostDetail";
import { usePostApplyAccept } from "@/hooks/queries/usePostApplyAccept";
import { usePostMakeChat } from "@/hooks/queries/usePostMakeChat";
import { usePutChatNewMember } from "@/hooks/queries/usePutChatNewMember";
import { colorTheme } from "@/style/color-theme";
import { checkChange } from "@/utils/apply-list-change-check";

export const ApplicantListBottomSheetPost = ({
  postId,
  onFinishApply,
}: ApplicantListBottomSheetPostProps) => {
  const [applyModal, setApplyModal] = useState<string>("");
  const [originApplyIds, setOriginApplyIds] = useState<ApplyListType[]>([]);
  const [applyIds, setApplyIds] = useState<ApplyListType[]>([]);
  const { mutate: putNewMember } = usePutChatNewMember();

  const { data } = useGetApplyList(postId);
  const { mutate: accept } = usePostApplyAccept(postId);
  const { data: postData } = useGetPostDetail(postId);

  const { mutate: makeChat } = usePostMakeChat();
  const chatRoomId = useCheckChatMake(postId);
  const [chatMakeRoomId, setChatMakeRoomId] = useState<ChatMakeRoom | null>(
    null,
  );
  const navigate = useNavigate();

  const [isApplyError, setIsApplyError] = useState("");
  const [isApplyChangeCheck, setIsApplyChangeCheck] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [isStatusChange, setIsStatusChange] = useState(false);

  const isRecruiting = postData
    ? postData.marketPostResponse.status === "RECRUITING"
      ? true
      : false
    : false;

  useEffect(() => {
    if (data && !isDataLoaded) {
      const tempApplyIds: ApplyListType[] = [];
      data?.map((item) => {
        if (item.status !== "WAITING" && item.status !== "TRADING_CANCEL") {
          tempApplyIds.push({
            applyId: item.applyId,
            userId: item.applicantInfo.userId,
          });
        }
      });
      setApplyIds(tempApplyIds);
      setOriginApplyIds(tempApplyIds);
      const timeoutId = setTimeout(() => {
        setIsDataLoaded(true);
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [data, isDataLoaded]);

  const GoToChatRoom = () => {
    const myId = localStorage.getItem("userId");
    if (chatMakeRoomId !== null && myId !== null) {
      navigate(`/chat/detail`, {
        state: {
          roomId: chatMakeRoomId.roomId,
          postId: chatMakeRoomId.postId,
          memberCount: chatMakeRoomId.memberCount,
          creatorId: myId,
        },
      });
    }
  };

  return (
    <Wrapper>
      <Title>참여관리</Title>
      <ListWrapper>
        <ApplicantItemList
          data={data!}
          applyIds={applyIds}
          setApplyIds={setApplyIds}
          isRecruiting={isRecruiting}
          setApplyModal={setIsApplyError}
        />
      </ListWrapper>
      <BottomFixed>
        <Button
          color="orange"
          onClick={() => {
            const tempAcceptList: number[] = applyIds.map((item) => {
              return item.applyId;
            });
            if (isRecruiting) {
              if (applyIds.length === 0) {
                setIsApplyError("APPLY_ID_LENGTH_ZERO");
              } else {
                accept(tempAcceptList, {
                  onSuccess: () => {
                    const tempList: string[] = applyIds.map((id) => {
                      return id.userId.toString();
                    });
                    if (chatRoomId === "" || chatRoomId === undefined) {
                      const tempData: ChatMakeRequest = {
                        postId: Number(postId),
                        memberIds: tempList,
                      };
                      makeChat(tempData, {
                        onSuccess: (res) => {
                          setApplyModal("PostNewMember");
                          setChatMakeRoomId(res);
                        },
                        onError: () => {
                          setIsApplyError("APPLY_CHAT_ERROR");
                        },
                      });
                    } else {
                      const tempData = {
                        chatRoomId: chatRoomId,
                        addingData: {
                          postId: Number(postId),
                          memberIds: tempList,
                        },
                      };
                      putNewMember(tempData, {
                        onSuccess: (res) => {
                          setApplyModal("PostNewMember");
                          setChatMakeRoomId(res);
                        },
                        onError: () => {
                          setIsApplyError("APPLY_CHAT_ERROR");
                        },
                      });
                    }
                  },
                  onError: () => {
                    setIsApplyError("APPLY_ID_LENGTH_OVER");
                  },
                });
              }
            } else {
              if (checkChange({ a: originApplyIds, b: applyIds })) {
                if (applyIds.length === 0) {
                  setIsApplyError("APPLY_ID_LENGTH_ZERO");
                } else {
                  setIsApplyError("APPLY_ID_NOT_CHANGE");
                }
              } else {
                if (originApplyIds.length > 0) {
                  setIsApplyChangeCheck(true);
                }
              }
            }
          }}
        >
          {applyIds.length}명 수락하기
        </Button>
      </BottomFixed>
      {applyModal !== "" && (
        <Modal
          onClose={() => {
            setApplyModal("");
            onFinishApply();
          }}
        >
          {(applyModal === "PostNewMember" ||
            applyModal === "ChangeNewMember") && (
            <Modal.Title text="신청 수락 완료" />
          )}
          {applyModal === "Finish" && (
            <Modal.Title text="이 게시물은 [모집완료] 상태가 되었습니다" />
          )}
          {applyModal === "KeepStatus" && (
            <Modal.Title text="이 게시물은 [모집중] 상태가 되었습니다" />
          )}
          <Modal.Button
            color="orange"
            onClick={() => {
              GoToChatRoom();
            }}
          >
            채팅방 가기
          </Modal.Button>
          <Modal.Button
            color="orange"
            onClick={() => {
              setApplyModal("");
              onFinishApply();
            }}
          >
            게시글 돌아가기
          </Modal.Button>
          <Modal.Button
            color="orange"
            onClick={() => {
              navigate("/post");
            }}
          >
            홈화면 가기
          </Modal.Button>
        </Modal>
      )}
      {isApplyError !== "" && (
        <Modal onClose={() => setIsApplyError("")}>
          {isApplyError === "APPLY_ID_LENGTH_ZERO" && (
            <Modal.Title text="수락할 지원자 선택 후 \n 수락해주세요" />
          )}
          {isApplyError === "APPLY_ID_LENGTH_OVER" && (
            <Modal.Title text="최대 신청자 수를 넘겼습니다" />
          )}
          {isApplyError === "APPLY_ID_NOT_CHANGE" && (
            <Modal.Title text="변경 사항이 없습니다." />
          )}
          {isApplyError === "IMPOSSIBLE_SELECT_APPLY" && (
            <Modal.Title text="[모집중] 상태에서는 \n 기존의 참여자를 \n 제외시킬 수 없습니다." />
          )}
          {isApplyError === "APPLY_CHAT_ERROR" && (
            <Modal.Title text="채팅방 생성 중 오류가 발생했습니다." />
          )}
        </Modal>
      )}
      {isApplyChangeCheck && (
        <ApplicantModifyModal
          setIsApplyChangeCheck={setIsApplyChangeCheck}
          applyIds={applyIds}
          originApplyIds={originApplyIds}
          postId={postId}
          chatRoomId={chatRoomId!}
          isPage={true}
          setChatMakeRoomId={setChatMakeRoomId}
          setApplyModal={setApplyModal}
          setStatusChangeModal={setIsStatusChange}
          setIsApplyError={setIsApplyError}
          maxNumOfPeople={
            postData ? postData.marketPostResponse.maxNumOfPeople : 0
          }
        />
      )}
      {isStatusChange && (
        <ApplicantOnlyDelete
          applyIds={applyIds}
          postId={postId}
          setApplyModal={setApplyModal}
          setStatusChangeModal={setIsStatusChange}
          isPage={true}
          onFinishApply={onFinishApply}
        />
      )}
    </Wrapper>
  );
};

const Wrapper = styled.div`
  height: 100%;
  padding-bottom: 4rem;
`;

const ListWrapper = styled.div`
  height: calc(100% - 4rem - 24px);
  overflow-y: scroll;

  &::-webkit-scrollbar {
    width: 10px;
    background-color: ${colorTheme.blue100};
  }
  &::-webkit-scrollbar-thumb {
    background-color: ${colorTheme.orange400};
    border-radius: 3px;
  }
`;

const Title = styled.div`
  padding: 1.72rem 0 1rem;
  font-size: 1.38rem;
  text-align: center;
`;

const BottomFixed = styled.div`
  display: flex;
  position: fixed;
  margin: 0 2rem;
  padding-bottom: 0 1.6rem 1.8rem;
  bottom: 1.6rem;
  gap: 11px;
  left: 0;
  right: 0;
  background-color: white;
`;

const Button = styled.button`
  position: relative;
  width: 100%;
  max-width: calc(480px - 3.2rem);
  margin: auto;
  padding: 12px;
  border: 1px solid transparent;
  background-color: ${colorTheme.blue900};
  border-radius: 50px;
  color: white;
  font-size: 1.3rem;
`;
