import { styled } from "styled-components";

export const PostingBoldText = styled.span`
  margin: 2.22rem 0px 2.5rem 0px;
  font-size: 1.67rem;
  color: black;
  text-align: center;
`;
