import { atom } from "recoil";

export const fcmTokenState = atom({
  key: "fcmTokenState",
  default: "",
});
