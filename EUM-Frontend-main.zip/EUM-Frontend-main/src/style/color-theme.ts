export const colorTheme = {
  blue900: "#253659",
  blue700: "#2D426C",
  blue500: "#4b6db4",
  blue300: "#93A8D2",
  blue100: "#E4E8F1",
  orange400: "#f17547",
  orange300: "#f59c7c",
  orange200: "#f9c4b0",
  orange100: "#fdebe5",
  shade: "#828282",
  gray300: "#ababab",
};
