import { useEffect } from "react";

export const GoogleAuth = () => {
  return null;
};
